# Installation 
```
pip install akshay-helloworld
```

# Usage
```python
from akshay_helloworld import *

hello_world()          #prints "Hello World from Akshay!!"

hello_world("User")    #prints "Hello User!!"
```
