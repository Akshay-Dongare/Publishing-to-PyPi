def hello_world(name=None):
    '''input any string'''
    if name==None:
        print("Hello World from Akshay!!")
    else:
        print(f"Hello {name}!!")